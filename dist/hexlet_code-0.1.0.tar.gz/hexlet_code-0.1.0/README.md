### Hexlet tests and linter status:
[![Actions Status](https://github.com/Nurlan-Aliev/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/Nurlan-Aliev/python-project-50/actions)